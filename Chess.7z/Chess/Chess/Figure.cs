﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Figure
{
    abstract class Figure
    {
        public string kolor;
        public string nazwa;
        public string pozycja;

        protected Figure(string kol, string naz, string poz)
        {
            if (kol.ToLower() != "bialy" && kol.ToLower() != "czarny")
            {
                kol = "bialy";
            }
            this.kolor = kol;
            this.nazwa = naz;
            this.pozycja = poz;
        }
        public virtual void toString()
        {
            Console.WriteLine(this.ToString());
        }

        public abstract Boolean canMove();
    }

    class Pionek : Figure
    {
        public Pionek(string kol, string naz, string poz) : base(kol, naz, poz)
        {
            if (kol.ToLower() != "bialy" && kol.ToLower() != "czarny")
            {
                kol = "bialy";
            }
            this.kolor = kol;
            this.nazwa = "Pionek";
            this.pozycja = poz;
        }

        public string Kolor { get; set; }
        public string Nazwa { get; set; }
        public string Pozycja { get; set; }
        public override void toString()
        {
            base.toString();
        }

        public override Boolean canMove()
        {
            return true;
        }
    }

    class Skoczek : Figure
    {
        public Skoczek(string kol, string naz, string poz) : base(kol, naz, poz)
        {
            if (kol.ToLower() != "bialy" && kol.ToLower() != "czarny")
            {
                kol = "bialy";
            }
            this.kolor = kol;
            this.nazwa = "Skoczek";
            this.pozycja = poz;
        }
        public string Kolor { get; set; }
        public string Nazwa { get; set; }
        public string Pozycja { get; set; }
        public override void toString()
        {
            base.toString();
        }
        public override Boolean canMove()
        {
            return true;
        }
    }

    class Hetman : Figure
    {
        public Hetman(string kol, string naz, string poz) : base(kol, naz, poz)
        {
            if (kol.ToLower() != "bialy" && kol.ToLower() != "czarny")
            {
                kol = "bialy";
            }
            this.kolor = kol;
            this.nazwa = "Hetman";
            this.pozycja = poz;
        }
        public string Kolor { get; set; }
        public string Nazwa { get; set; }
        public string Pozycja { get; set; }
        public override void toString()
        {
            base.toString();
        }
        public override Boolean canMove()
        {
            return true;
        }
    }

    class Goniec : Figure
    {
        public Goniec(string kol, string naz, string poz) : base(kol, naz, poz)
        {
            if (kol.ToLower() != "bialy" && kol.ToLower() != "czarny")
            {
                kol = "bialy";
            }
            this.kolor = kol;
            this.nazwa = "Goniec";
            this.pozycja = poz;
        }
        public string Kolor { get; set; }
        public string Nazwa { get; set; }
        public string Pozycja { get; set; }
        public override void toString()
        {
            base.toString();
        }
        public override Boolean canMove()
        {
            return true;
        }
    }
}
