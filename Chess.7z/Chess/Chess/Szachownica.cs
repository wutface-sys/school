﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Szachownica
{
    class Szachownica
    {
        public Figure.Figure[,] szachownica = new Figure.Figure[8, 8];

        public Szachownica()
        {

        }

        public void move(Figure.Figure figura, string pole)
        {
            if (pole.ToLower() == "a1")
            {
                this.szachownica[0, 0] = figura;
            }
            else if (pole.ToLower() == "a2")
            {
                this.szachownica[0, 1] = figura;
            }
            else if (pole.ToLower() == "a3")
            {
                this.szachownica[0, 2] = figura;
            }
            else if (pole.ToLower() == "a4")
            {
                this.szachownica[0, 3] = figura;
            }
            else if (pole.ToLower() == "a5")
            {
                this.szachownica[0, 4] = figura;
            }
            else if (pole.ToLower() == "a6")
            {
                this.szachownica[0, 5] = figura;
            }
            else if (pole.ToLower() == "a7")
            {
                this.szachownica[0, 6] = figura;
            }
            else if (pole.ToLower() == "a8")
            {
                this.szachownica[0, 7] = figura;
            }
            else if (pole.ToLower() == "b1")
            {
                this.szachownica[1, 0] = figura;
            }
            else if (pole.ToLower() == "b2")
            {
                this.szachownica[1, 1] = figura;
            }
            else if (pole.ToLower() == "b3")
            {
                this.szachownica[1, 2] = figura;
            }
            else if (pole.ToLower() == "b4")
            {
                this.szachownica[1, 3] = figura;
            }
            else if (pole.ToLower() == "b5")
            {
                this.szachownica[1, 4] = figura;
            }
            else if (pole.ToLower() == "b6")
            {
                this.szachownica[1, 5] = figura;
            }
            else if (pole.ToLower() == "b7")
            {
                this.szachownica[1, 6] = figura;
            }
            else if (pole.ToLower() == "b8")
            {
                this.szachownica[1, 7] = figura;
            }
            else if (pole.ToLower() == "c1")
            {
                this.szachownica[2, 0] = figura;
            }
            else if (pole.ToLower() == "c2")
            {
                this.szachownica[2, 1] = figura;
            }
            else if (pole.ToLower() == "c3")
            {
                this.szachownica[2, 2] = figura;
            }
            else if (pole.ToLower() == "c4")
            {
                this.szachownica[2, 3] = figura;
            }
            else if (pole.ToLower() == "c5")
            {
                this.szachownica[2, 4] = figura;
            }
            else if (pole.ToLower() == "c6")
            {
                this.szachownica[2, 5] = figura;
            }
            else if (pole.ToLower() == "c7")
            {
                this.szachownica[2, 6] = figura;
            }
            else if (pole.ToLower() == "c8")
            {
                this.szachownica[2, 7] = figura;
            }
            else if (pole.ToLower() == "d1")
            {
                this.szachownica[3, 0] = figura;
            }
            else if (pole.ToLower() == "d2")
            {
                this.szachownica[3, 1] = figura;
            }
            else if (pole.ToLower() == "d3")
            {
                this.szachownica[3, 2] = figura;
            }
            else if (pole.ToLower() == "d4")
            {
                this.szachownica[3, 3] = figura;
            }
            else if (pole.ToLower() == "d5")
            {
                this.szachownica[3, 4] = figura;
            }
            else if (pole.ToLower() == "d6")
            {
                this.szachownica[3, 5] = figura;
            }
            else if (pole.ToLower() == "d7")
            {
                this.szachownica[3, 6] = figura;
            }
            else if (pole.ToLower() == "d8")
            {
                this.szachownica[3, 7] = figura;
            }
            else if (pole.ToLower() == "e1")
            {
                this.szachownica[4, 0] = figura;
            }
            else if (pole.ToLower() == "e2")
            {
                this.szachownica[4, 1] = figura;
            }
            else if (pole.ToLower() == "e3")
            {
                this.szachownica[4, 2] = figura;
            }
            else if (pole.ToLower() == "e4")
            {
                this.szachownica[4, 3] = figura;
            }
            else if (pole.ToLower() == "e5")
            {
                this.szachownica[4, 4] = figura;
            }
            else if (pole.ToLower() == "e6")
            {
                this.szachownica[4, 5] = figura;
            }
            else if (pole.ToLower() == "e7")
            {
                this.szachownica[4, 6] = figura;
            }
            else if (pole.ToLower() == "e8")
            {
                this.szachownica[4, 7] = figura;
            }
            else if (pole.ToLower() == "f1")
            {
                this.szachownica[5, 0] = figura;
            }
            else if (pole.ToLower() == "f2")
            {
                this.szachownica[5, 1] = figura;
            }
            else if (pole.ToLower() == "f3")
            {
                this.szachownica[5, 2] = figura;
            }
            else if (pole.ToLower() == "f4")
            {
                this.szachownica[5, 3] = figura;
            }
            else if (pole.ToLower() == "f5")
            {
                this.szachownica[5, 4] = figura;
            }
            else if (pole.ToLower() == "f6")
            {
                this.szachownica[5, 5] = figura;
            }
            else if (pole.ToLower() == "f7")
            {
                this.szachownica[5, 6] = figura;
            }
            else if (pole.ToLower() == "f8")
            {
                this.szachownica[5, 7] = figura;
            }
            else if (pole.ToLower() == "g1")
            {
                this.szachownica[6, 0] = figura;
            }
            else if (pole.ToLower() == "g2")
            {
                this.szachownica[6, 1] = figura;
            }
            else if (pole.ToLower() == "g3")
            {
                this.szachownica[6, 2] = figura;
            }
            else if (pole.ToLower() == "g4")
            {
                this.szachownica[6, 3] = figura;
            }
            else if (pole.ToLower() == "g5")
            {
                this.szachownica[6, 4] = figura;
            }
            else if (pole.ToLower() == "g6")
            {
                this.szachownica[6, 5] = figura;
            }
            else if (pole.ToLower() == "g7")
            {
                this.szachownica[6, 6] = figura;
            }
            else if (pole.ToLower() == "g8")
            {
                this.szachownica[6, 7] = figura;
            }
            else if (pole.ToLower() == "h1")
            {
                this.szachownica[7, 0] = figura;
            }
            else if (pole.ToLower() == "h2")
            {
                this.szachownica[7, 1] = figura;
            }
            else if (pole.ToLower() == "h3")
            {
                this.szachownica[7, 2] = figura;
            }
            else if (pole.ToLower() == "h4")
            {
                this.szachownica[7, 3] = figura;
            }
            else if (pole.ToLower() == "h5")
            {
                this.szachownica[7, 4] = figura;
            }
            else if (pole.ToLower() == "h6")
            {
                this.szachownica[7, 5] = figura;
            }
            else if (pole.ToLower() == "h7")
            {
                this.szachownica[7, 6] = figura;
            }
            else if (pole.ToLower() == "h8")
            {
                this.szachownica[7, 7] = figura;
            }
        }

    }
}
