﻿using System;

namespace Chess
{
    class Program
    {
        static void Main(string[] args)
        {

            Figure.Pionek p = new Figure.Pionek("bialy", "hetman", "a3");
            p.toString();
            Figure.Figure f = p;
            f.toString();
        }
    }
}
